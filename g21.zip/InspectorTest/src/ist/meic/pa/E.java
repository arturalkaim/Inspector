package ist.meic.pa;

public class E extends B {
	boolean f;

	public int g(int h) {
		return d + h;
	}

	public static long i = 10L;

}
