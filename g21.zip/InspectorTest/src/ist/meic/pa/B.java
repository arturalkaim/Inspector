package ist.meic.pa;

public class B {
	private String c = "Hello World";
	protected int d;
	private B g;
	
	private String h(int a, String b, float c){
		return a + b + c;
	}
}
